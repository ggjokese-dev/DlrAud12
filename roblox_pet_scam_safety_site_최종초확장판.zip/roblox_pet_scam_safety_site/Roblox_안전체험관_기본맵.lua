-- Roblox 안전 체험관 기본 맵 만들기
-- 사용법: Roblox Studio에서 새 Baseplate를 만든 뒤
-- View > Command Bar를 열고 이 코드를 붙여넣어 실행하세요.
-- 처음에는 복사본에서 테스트하세요.

local Workspace = game:GetService("Workspace")

local old = Workspace:FindFirstChild("SafetyTrainingMap")
if old then old:Destroy() end

local folder = Instance.new("Folder")
folder.Name = "SafetyTrainingMap"
folder.Parent = Workspace

local function part(name, size, pos, color, text)
    local p = Instance.new("Part")
    p.Name = name
    p.Size = size
    p.Position = pos
    p.Anchored = true
    p.Color = color
    p.Parent = folder

    if text then
        local gui = Instance.new("BillboardGui")
        gui.Size = UDim2.new(0,220,0,60)
        gui.StudsOffset = Vector3.new(0,5,0)
        gui.AlwaysOnTop = true
        gui.Parent = p

        local label = Instance.new("TextLabel")
        label.Size = UDim2.fromScale(1,1)
        label.BackgroundTransparency = 0.2
        label.TextScaled = true
        label.Text = text
        label.Parent = gui
    end
    return p
end

-- 바닥
part("MainFloor", Vector3.new(180,1,120), Vector3.new(0,0,0), Color3.fromRGB(230,235,242), nil)

-- 시작 지점
local spawn = Instance.new("SpawnLocation")
spawn.Name = "SafetySpawn"
spawn.Size = Vector3.new(10,1,10)
spawn.Position = Vector3.new(0,2,0)
spawn.Anchored = true
spawn.Parent = folder

local zones = {
    {"거래 광장", Vector3.new(-55,4,-30), Color3.fromRGB(90,170,110), "거래 안전"},
    {"계정 보안실", Vector3.new(0,4,-30), Color3.fromRGB(80,130,210), "비밀번호·2SV"},
    {"링크 검사실", Vector3.new(55,4,-30), Color3.fromRGB(230,180,70), "링크 확인"},
    {"채팅 신고실", Vector3.new(-55,4,30), Color3.fromRGB(170,100,190), "도배·괴롭힘"},
    {"신고 센터", Vector3.new(0,4,30), Color3.fromRGB(210,80,80), "사용자·체험·아이템"},
    {"개발자실", Vector3.new(55,4,30), Color3.fromRGB(80,170,180), "Studio·스크립트"},
}

for _, z in ipairs(zones) do
    part(z[1], Vector3.new(28,7,20), z[2], z[3], z[4])
end

-- 가운데 안내판
part("GuideBoard", Vector3.new(40,8,2), Vector3.new(0,7,0), Color3.fromRGB(35,45,60),
    "🛡️ 모르면 멈추기  →  확인하기  →  기록하기  →  신고하기")

print("Roblox 안전 체험관 기본 맵이 만들어졌습니다.")
